package com.spring.springTest.dto;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserDTOMapper implements RowMapper<UserDTO>
{ 	 	
	@Override
	public UserDTO mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		// TODO Auto-generated method stub
		UserDTO userDto =null;
		try 
		{
			userDto = new UserDTO();
			userDto.setId(rs.getLong("test_data"));
			userDto.setName(rs.getString("name"));
			userDto.setAddress(rs.getString("address"));

			return userDto;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return userDto;	
	}
}
