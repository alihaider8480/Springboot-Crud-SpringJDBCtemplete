package com.spring.springTest.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.spring.springTest.dto.UserDTO;
import com.spring.springTest.dto.UserDTOMapper;

@Repository
@Transactional
public class UserRepository2 {

	@Autowired
	JdbcTemplate jdbcTemplate;
//	
//	private static final String SQL_FETCH ="Select * from user where name=?";
//	
//	public UserDTO fetchUser(String name) {
//		try {
//			return jdbcTemplate.queryForObject(name, name);
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
	
	public List<UserDTO> findAll() 
	{
		UserDTOMapper mapper = new UserDTOMapper();
		return jdbcTemplate.query("select * from test.test1", mapper);
	}
	
	public int insertUser(UserDTO userDto)
	{
		return jdbcTemplate.update("insert into test.test1 values(?,?,?)",new  Object[] {userDto.getId() , userDto.getName() , userDto.getAddress()});
	}
	
	public int updateUser(UserDTO userDto)
	{
		System.out.println("Update name : "+userDto.getName()+" Address : "+userDto.getAddress()+" ID : "+ userDto.getId());
		return jdbcTemplate.update("update test1 set name = ?, address = ? where test_data = ?",new  Object[] {userDto.getName() , userDto.getAddress(), userDto.getId()});
	}
	
	public int deleteUser(Long id)
	{
		System.out.println("delete id : "+id);
		return jdbcTemplate.update("delete from test1 where test_data = ?",new  Object[] {id});
	}
}